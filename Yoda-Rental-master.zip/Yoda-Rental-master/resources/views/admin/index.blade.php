@extends('layouts.admin')

@section('content')
    <div class="card">
        <div class="cardbody">
            <h1>Yoda Rental</h1>
        </div>
    </div>
@endsection